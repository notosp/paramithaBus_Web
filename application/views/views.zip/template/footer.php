<div class="footer-bottom-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> Paramitha Bus</p>
			</div>
		</div>
	</div>
</div>
</section>
<div class="scroll-top">
	<img src="<?= base_url('assets')?>/scroll-up.png" alt="JSOFT">
</div>
    <script src="<?= base_url('assets/js')?>/jquery-3.2.1.min.js"></script>
    <!--=== Jquery Migrate Min Js ===-->
    <script src="<?= base_url('assets/js')?>/jquery-migrate.min.js"></script>
    <!--=== Popper Min Js ===-->
    <script src="<?= base_url('assets/js')?>/popper.min.js"></script>
    <!--=== Bootstrap Min Js ===-->
    <script src="<?= base_url('assets/js')?>/bootstrap.min.js"></script>
    <!--=== Gijgo Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/gijgo.js"></script>
    <!--=== Vegas Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/vegas.min.js"></script>
    <!--=== Isotope Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/isotope.min.js"></script>
    <!--=== Owl Caousel Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/owl.carousel.min.js"></script>
    <!--=== Waypoint Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/waypoints.min.js"></script>
    <!--=== CounTotop Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/counterup.min.js"></script>
    <!--=== YtPlayer Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/mb.YTPlayer.js"></script>
    <!--=== Magnific Popup Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/magnific-popup.min.js"></script>
    <!--=== Slicknav Min Js ===-->
    <script src="<?= base_url('assets/js')?>/plugins/slicknav.min.js"></script>
    <!--=== Mian Js ===-->
    <script src="<?= base_url('assets/js')?>/main.js"></script>

	

