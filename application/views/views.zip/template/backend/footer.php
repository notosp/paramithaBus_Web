<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <strong>Copyright &copy; 2019 <a href="#">Paramitha Bus</a>.</strong> All rights reserved.    
    </div>
    
</footer>