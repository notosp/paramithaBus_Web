 <div class="preloader">
	<div class="preloader-spinner">
		<div class="loader-content">
			<img src="<?= base_url('assets/img')?>/preloader.gif" alt="JSOFT">
		</div>
	</div>
</div>
