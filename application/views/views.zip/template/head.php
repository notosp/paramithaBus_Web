<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?= base_url('assets')?>/bus.png" type="image/x-icon" />

	<title>Paramitha Bus</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="<?= base_url('assets/css')?>/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/css')?>/plugins/vegas.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/css')?>/plugins/slicknav.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/css')?>/plugins/magnific-popup.css" rel="stylesheet">
    <link href="<?= base_url('assets/css')?>/plugins/owl.carousel.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/css')?>/plugins/gijgo.css" rel="stylesheet">
    <link href="<?= base_url('assets/css')?>/font-awesome.css" rel="stylesheet">
    <link href="<?= base_url('assets/css')?>/reset.css" rel="stylesheet">
    <link href="<?= base_url('assets')?>/style.css" rel="stylesheet">
    <link href="<?= base_url('assets/css')?>/responsive.css" rel="stylesheet">

</head>
