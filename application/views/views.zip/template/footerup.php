
<section id="footer-area">
<div class="footer-widget-area">
	<div class="container">
		<div class="row">
			<?php
			foreach ($data1->result_array() as $j) :
			$id_about=$j['id_about'];
			$nama=$j['nama_po'];
			$about=$j['about'];
			$alamat=$j['alamat'];
			$phone=$j['phone'];
			$fb=$j['fb'];
			$ig=$j['ig'];
			$twit=$j['twitter'];
			?>  
			<div class="col-lg-4 col-md-6">
				<div class="single-footer-widget">
					<h2>About Us</h2>
					<div class="widget-body">
						<p style="text-align:justify"><?= $about?></p>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6">
				<div class="single-footer-widget">
					<h2>Contact</h2>
					<div class="widget-body">
						<p> Paramitha BUS Pariwisata beralamat di <?= $alamat?></p>

						<a href="https://goo.gl/maps/b5mt45MCaPB2" class="map-show" target="_blank">Show Location</a>
						<ul class="get-touch">
						<li>NO.Telp : <i class="fa fa-mobile"></i><?= $phone?></li>
						<li>Instagram : <i class="fa fa-instagram"></i><?= $ig?></li>
						<li>Facebook : <i class="fa fa-facebook"></i><?= $fb?></li>
						<li>Twitter : <i class="fa fa-twitter"></i><?= $twit?></li>
						</ul>
					</div>
				</div>
			</div>
			<?php endforeach?>
		    
			
			<div class="col-lg-4 col-md-6">
				<div class="single-footer-widget">
					<div class="widget-body">
					<h2>Popular Post</h2>
					<?php 
					$query=$this->db->query("SELECT * FROM berita ORDER BY views_berita DESC LIMIT 3");
					?>
						<?php 
						foreach ($query->result_array() as $i) :
						$id_berita=$i['id_berita'];
						$judul_berita=$i['judul_berita'];
						$views_berita=$i['views_berita'];
						?>
						<ul class="recent-post">
							<li>
								<a href="#">
									<?= $judul_berita?> 
									<p style="color:white">Jumlah Viewer: <?= $views_berita?></p>
									<i class="fa fa-long-arrow-right"></i>
								</a>
							</li>
					<?php endforeach?>
						</ul>
						
					</div>
				</div>
			</div>
			
		</div>
	</div>
</div>
